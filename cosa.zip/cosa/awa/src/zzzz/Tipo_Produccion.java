package zzzz;
public class Tipo_Produccion {
    int ID;
    String Name;
    String Unidad;

    public Tipo_Produccion(){}
    public Tipo_Produccion(int id,String name,String unidad){
        ID=id;
        Name=name;
        

    }




}
