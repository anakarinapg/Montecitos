package zzzz;
import Modulo.Usuario;

public class Administrador extends Usuario {
    
}
