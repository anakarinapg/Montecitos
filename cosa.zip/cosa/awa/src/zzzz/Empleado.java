package zzzz;
import Modulo.Usuario;

public class Empleado extends Usuario {
    
}
